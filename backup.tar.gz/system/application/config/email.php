<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$config['charset'] = 'iso-8859-1';
$config['mailtype'] = 'html';



/* End of file email.php */
/* Location: ./system/application/config/email.php */