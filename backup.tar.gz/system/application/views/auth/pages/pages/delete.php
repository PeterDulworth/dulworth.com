<h1>
	Delete Page "<?= $page['name'] ?>"?
</h1>

<p align="center">
	<a class="button" href="/admin/pages/delete/<?= $page['id'] ?>/confirm">Yes, I Do!</a>&nbsp;&nbsp;<a class="button" href="/admin/pages">No, Thanks!</a>
</p>