<?php include($this->config->item('full_path') . 'system/application/views/auth/tinymce.php'); ?>

<h1>
	Edit Page
</h1>

<?php echo validation_errors('<p class="error">', '</p>'); ?>
<?php echo form_open('admin/pages/edit/' . $page['id'], array('id' => 'pageedit')); ?>
<?php if( $page['parent_id'] != '1000' )
{
?>
	<div class="input_field">
		<label for="parent_id" class="">Parent</label>
	<div class="clear">&nbsp;</div>
		<select id="" class="input selectfield" name="parent_id">
			<option value="0">None</option>
			<?php
			if( count($sitetree) > 0)
			{
				foreach ($sitetree as $row)
				{
				?>
					<option value="<?= $row['id']; ?>"<?= set_select('parent_id', $row['id']); ?><?= ($row['level'] >= $page_move_limit ? "disabled" : ""); ?><? if( !$_POST && $row['id'] == $page['parent_id']){ echo "selected"; }?>>
						<?= nbs($row['level']); ?><?= $row['name']; ?>
					</option>
				<?php
				}
			}
			?>
		</select>
	</div>
	<div class="clear">&nbsp;</div>
<?php
}
?>	
	<div class="input_field">
		<label for="name" class="">Name</label>
	<div class="clear">&nbsp;</div>
		<input id="" class="input bigfield" type="text" name="name" value="<?php echo set_value('name', $page['name']); ?>" />
	</div>
	<div class="clear">&nbsp;</div>
	<?php /*
	<div class="input_field">
		<label for="banner" class="">Banner</label>
	<div class="clear">&nbsp;</div>
		<input id="banner" class="input bigfield" type="text" name="banner" value="<?php echo set_value('banner', $page['banner']); ?>" /><a href="javascript:;" onclick="mcImageManager.browse({fields : 'banner', remove_script_host : true, rootpath : '{0}/banner', remember_last_path : false});" title="Select an Image..." class="imgbutton"><img src="/images/admin/browse.gif" border="0" title="Select an Image..." alt="Select an Image..." /></a>
	</div>
	<div class="clear">&nbsp;</div>

	<div class="input_field">
		<label for="media" class="">Media</label>
	<div class="clear">&nbsp;</div>
		<select id="" class="input selectfield" name="media">
			<option value="0"<?php echo set_select('media', '0', TRUE); ?>>None</option>
			<optgroup label="Galleries">
			<?php
			if( count($galleries) > 0)
			{
				foreach ($galleries as $row)
				{
				?>
					<option value="<?= $row['id']; ?>"<?= set_select('media', $row['id']); ?><? if( !$_POST && $row['id'] == $page['media']){ echo "selected"; }?>>
						<?= $row['name']; ?>
					</option>
				<?php
				}
			}
			?>
			</optgroup>
		</select>
	</div>
	<div class="clear">&nbsp;</div>
	*/ ?>
	<div class="input_field">
		<label for="content" class="">Content</label>
	<div class="clear">&nbsp;</div>
		<textarea id="" class="input textarea tinymce" name="content"><?php echo set_value('content', $page['content']); ?></textarea>
	</div>
	<div class="clear">&nbsp;</div>
	
	<div class="input_field">
		<label for="meta_title" class="">Meta Title</label>
	<div class="clear">&nbsp;</div>
		<input id="" class="input bigfield" type="text" name="meta_title" value="<?php echo set_value('meta_title', $page['meta_title']); ?>" />
	</div>
	<div class="clear">&nbsp;</div>
	
	<div class="input_field">
		<label for="meta_desc" class="">Meta Desc</label>
	<div class="clear">&nbsp;</div>
		<input id="" class="input bigfield" type="text" name="meta_desc" value="<?php echo set_value('meta_desc', $page['meta_desc']); ?>" />
	</div>
	<div class="clear">&nbsp;</div>
	
	<div class="input_field">
		<label for="meta_keywords" class="">Meta Keywords</label>
	<div class="clear">&nbsp;</div>
		<input id="" class="input bigfield" type="text" name="meta_keywords" value="<?php echo set_value('meta_keywords', $page['meta_keywords']); ?>" />
	</div>
	<div class="clear">&nbsp;</div>
	
	<div class="input_field">
		<label for="meta_footer" class="">Meta Footer</label>
	<div class="clear">&nbsp;</div>
		<input id="" class="input bigfield" type="text" name="meta_footer" value="<?php echo set_value('meta_footer', $page['meta_footer']); ?>" />
	</div>
	<div class="clear">&nbsp;</div>
	
	<div class="input_field">
		<label for="submit" class="">&nbsp;</label>
	<div class="clear">&nbsp;</div>
		<input class="submit" type="submit" name="submit" value="submit" />
	</div>
	<div class="clear">&nbsp;</div>
</form>