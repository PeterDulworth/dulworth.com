<h1>
	Manage Pages
</h1>

<?php include($this->config->item('full_path') . 'system/application/views/auth/flashdata.php'); ?>

<h4>
	Home
</h4>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
<thead>
	<tr>
		<th align="left">Name</th>
		<th width="250">Updated</th>
		<th width="100">Action</th>
	</tr>
</thead>
<tbody>
<?php
if( count($settings) > 0 )
{
	foreach ($settings as $row)
	{
	?>
	<tr>
		<td>
			<?= humanize($row['name']); ?>
		</td>
		<td>
			<?= timespan(mysql_to_unix($row['updated_at']), now()) . " Ago"; ?>
		</td>
		<td align="center">
			<a class="button" href="/admin/settings/edit/<?= $row['id']; ?>">Edit</a>
		</td>
	</tr>
	<?
	}
}
?>
	
</tbody>
</table>

<h4>
	Content
</h4>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
<thead>
	<tr>
		<th align="left">Name</th>
		<th width="75">Status</th>
		<th width="250">Updated</th>
		<th width="100">Action</th>
	</tr>
</thead>
<tbody>
<?php
if( count($pages) > 0 )
{
	foreach ($pages as $page)
	{
	?>
	<tr>
		<td>
			<?= nbs($page['level']); ?>
			<a href="/admin/pages/move/up/<?= $page['id']; ?>"><img src="/images/admin/arrow_up.gif" /></a>
			<a href="/admin/pages/move/down/<?= $page['id']; ?>"><img src="/images/admin/arrow_down.gif" /></a>
			<?= $page['name']; ?>
		</td>
		<td align="center">
			<?php
			switch( $page['status'] )
			{
				case 0:
					echo "Active";
					break;
				case 1:
					echo "Inactive";
					break;
				default:
					echo "Unknown";
			}
			?>
		</td>
		<td>
			<?= timespan(mysql_to_unix($page['updated_at']), now()) . " Ago"; ?>
		</td>
		<td align="center">
			<a class="button" href="/admin/pages/edit/<?= $page['id']; ?>">Edit</a>
			&nbsp;|&nbsp;
			<a class="button" href="/admin/pages/delete/<?= $page['id']; ?>">Delete</a>
		</td>
	</tr>
	<?
	}
}
?>
	<tr>
		<td class="tmenu" colspan="4" align="right">
			<?php echo anchor($this->config->item('auth_controllers_root') . "pages/add", "Add Page"); ?>
		</td>
	</tr>
</tbody>
</table>


<h4>
	Extras
</h4>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
<thead>
	<tr>
		<th align="left">Name</th>
		<th width="75">Status</th>
		<th width="250">Updated</th>
		<th width="100">Action</th>
	</tr>
</thead>
<tbody>
<?php
if( count($pages_noparent) > 0 )
{
	foreach ($pages_noparent as $page)
	{
	?>
	<tr>
		<td>
			<?= $page['name']; ?>
		</td>
		<td align="center">
			<?php
			switch( $page['status'] )
			{
				case 0:
					echo "Active";
					break;
				case 1:
					echo "Inactive";
					break;
				default:
					echo "Unknown";
			}
			?>
		</td>
		<td>
			<?= timespan(mysql_to_unix($page['updated_at']), now()) . " Ago"; ?>
		</td>
		<td align="center">
			<a class="button" href="/admin/pages/edit/<?= $page['id']; ?>">Edit</a>
			&nbsp;|&nbsp;
			<a class="button" href="/admin/pages/delete/<?= $page['id']; ?>">Delete</a>
		</td>
	</tr>
	<?
	}
}
?>
	<tr>
		<td class="tmenu" colspan="4" align="right">
			<?php echo anchor($this->config->item('auth_controllers_root') . "pages/add", "Add Page"); ?>
		</td>
	</tr>
</tbody>
</table>