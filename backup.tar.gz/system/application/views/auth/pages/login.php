<h2>
	Login
</h2>

<?php echo validation_errors('<p class="error">', '</p>'); ?>

<form method="POST">
	<div class="input_field">
		<label for="username" class="">Username/Email</label>
	<div class="clear">&nbsp;</div>
		<input id="" class="input bigfield" type="text" name="username" value="<?php echo set_value('username'); ?>" />
	</div>
	<div class="clear">&nbsp;</div>
	
	<div class="input_field">
		<label for="pasword" class="">Password</label>
	<div class="clear">&nbsp;</div>
		<input id="" class="input bigfield" type="password" name="password" value="<?php echo set_value('password'); ?>" />
	</div>
	<div class="clear">&nbsp;</div>
	
	<div class="input_field">
		<label for="submit" class="">&nbsp;</label>
	<div class="clear">&nbsp;</div>
		<input class="submit" type="submit" name="login" value="Login" />
	</div>
	<div class="clear">&nbsp;</div>
</form>