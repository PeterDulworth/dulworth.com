<div id="login">
		
		<h2>Success!</h2>
		<div class="box">
			<?php echo $msg; ?>
		</div>
</div>