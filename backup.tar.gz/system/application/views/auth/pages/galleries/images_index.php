<h1>
	Manage <?php echo $gallery['name']; ?> Gallery
</h1>

<?php include($this->config->item('full_path') . 'system/application/views/auth/flashdata.php'); ?>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
<thead>
	<tr>
		<th width="40"></th>
		<th align="left">Name</th>
		<th align="left" width="200">Image</th>
		<th width="150">Action</th>
	</tr>
</thead>
<tbody>
	<tr>
		<td class="tmenu" colspan="4" align="right">
			<?php echo anchor($this->config->item('auth_controllers_root') . "galleries/images_add/" . $gallery['id'], "Add Image"); ?>
		</td>
	</tr>
<?php
if( count($images) > 0 )
{
	foreach ($images as $row)
	{
	?>
	<tr>
		<td>
			<a href="/admin/galleries/images_move/up/<?= $row['id']; ?>"><img src="/images/admin/arrow_up.gif" /></a>
			<a href="/admin/galleries/images_move/down/<?= $row['id']; ?>"><img src="/images/admin/arrow_down.gif" /></a>
		</td>
		<td>
			<strong><?php echo $row['name']; ?></strong><br />
			<?php echo $row['description']; ?>
		</td>
		<td>
			<?php echo img(array('src' => $row['image'], 'height' => '100')); ?>
		</td>
		<td align="center">
			<a class="button" href="/admin/galleries/images_edit/<?= $row['id']; ?>">Edit</a>
			&nbsp;|&nbsp;
			<a class="button" href="/admin/galleries/images_delete/<?= $row['id']; ?>">Delete</a>
		</td>
	</tr>
	<?
	}
} else
{
?>
	<tr>
		<td colspan="4" align="center">
			-none to display-
		</td>
	</tr>
<?
}
?>
	<tr>
		<td class="tmenu" colspan="4" align="right">
			<?php echo anchor($this->config->item('auth_controllers_root') . "galleries/images_add/" . $gallery['id'], "Add Image"); ?>
		</td>
	</tr>
</tbody>
</table>