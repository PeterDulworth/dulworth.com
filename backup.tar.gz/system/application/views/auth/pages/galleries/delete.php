<h1>
	Delete Gallery "<?= $gallery['name'] ?>"?
</h1>

<p align="center">
	<a class="button" href="/admin/galleries/delete/<?= $gallery['id'] ?>/confirm">Yes!</a>&nbsp;|&nbsp;<a class="button" href="/admin/galleries">No, Thanks!</a>
</p>