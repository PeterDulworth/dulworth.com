<?php include($this->config->item('full_path') . 'system/application/views/auth/tinymce.php'); ?>

<h1>
	Edit Image
</h1>

<?php echo validation_errors('<p class="error">', '</p>'); ?>
<?php echo form_open('admin/galleries/images_edit/' . $image['id']); ?>

	<div class="input_field">
		<label for="name" class="">Name</label>
	<div class="clear">&nbsp;</div>
		<input id="" class="input bigfield" type="text" name="name" value="<?php echo set_value('name', $image['name']); ?>" />
	</div>
	<div class="clear">&nbsp;</div>

	<div class="input_field">
		<label for="image" class="">Image</label>
	<div class="clear">&nbsp;</div>
		<input id="image" class="input bigfield" type="text" name="image" value="<?php echo set_value('image', $image['image']); ?>" /><a href="javascript:;" onclick="mcImageManager.browse({fields : 'image', remove_script_host : true, rootpath : '{0}/galleries/<?php echo $this->uri->segment(4); ?>', remember_last_path : false});" title="Select an Image..." class="imgbutton"><img src="/images/admin/browse.gif" border="0" title="Select an Image..." alt="Select an Image..." /></a>
	</div>
	<div class="clear">&nbsp;</div>

	<div class="input_field">
		<label for="image_thumb" class="">Image Thumbnail</label>
	<div class="clear">&nbsp;</div>
		<input id="image_thumb" class="input bigfield" type="text" name="image_thumb" value="<?php echo set_value('image_thumb', $image['image_thumb']); ?>" /><a href="javascript:;" onclick="mcImageManager.browse({fields : 'image_thumb', remove_script_host : true, rootpath : '{0}/galleries/<?php echo $this->uri->segment(4); ?>', remember_last_path : false});" title="Select an Image..." class="imgbutton"><img src="/images/admin/browse.gif" border="0" title="Select an Image..." alt="Select an Image..." /></a>
	</div>
	<div class="clear">&nbsp;</div>

	<div class="input_field">
		<label for="description" class="">Description</label>
	<div class="clear">&nbsp;</div>
		<textarea id="" class="input textarea tinymce" name="description"><?php echo set_value('description', $image['description']); ?></textarea>
	</div>
	<div class="clear">&nbsp;</div>
	
	<div class="input_field">
		<label for="submit" class="">&nbsp;</label>
	<div class="clear">&nbsp;</div>
		<input class="submit" type="submit" name="submit" value="submit" />
	</div>
	<div class="clear">&nbsp;</div>
</form>