<h1>
	Delete Image "<?php echo $image['name'] ?>"?
</h1>

<p align="center">
	<a class="button" href="/admin/galleries/images_delete/<?= $image['id'] ?>/confirm">Yes!</a>&nbsp;|&nbsp;<a class="button" href="/admin/galleries/images/<?= $image['parent_id'] ?>">No, Thanks!</a>
</p>