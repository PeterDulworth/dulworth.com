<h1>
	Manage Galleries
</h1>

<?php include($this->config->item('full_path') . 'system/application/views/auth/flashdata.php'); ?>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
<thead>
	<tr>
		<th align="left">Name</th>
		<th width="150">Action</th>
	</tr>
</thead>
<tbody>
<?php
if( count($galleries) > 0 )
{
	foreach ($galleries as $row)
	{
	?>
	<tr>
		<td>
			<?php echo anchor($this->config->item('auth_controllers_root') . 'galleries/images/' . $row['id'], $row['name']); ?>
		</td>
		<td align="left">
			<a class="button" href="/admin/galleries/images/<?= $row['id']; ?>">Manage</a>
			&nbsp;|&nbsp;
			<a class="button" href="/admin/galleries/edit/<?= $row['id']; ?>">Edit</a>
			&nbsp;|&nbsp;
			<a class="button" href="/admin/galleries/delete/<?= $row['id']; ?>">Delete</a>
		</td>
	</tr>
	<?
	}
}
?>
	<tr>
		<td class="tmenu" colspan="4" align="right">
			<?php echo anchor($this->config->item('auth_controllers_root') . "galleries/add", "Add Gallery"); ?>
		</td>
	</tr>
</tbody>
</table>