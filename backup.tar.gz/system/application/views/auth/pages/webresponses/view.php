<h1>
	View Web Response
</h1>
   <style type="text/css" media="screen">
      
      td.mainbar {
      	padding: 22px 0 0 14px;
      	text-align: left;
      }

      .mainbar p {
      	font-family: 'Lucida Grande';
      	font-size: 12px;
      	color: #333333;
      	margin: 0 0 10px 0;
      	text-align: left;
      }

      .mainbar p.first {
      	margin-top: 10px;
      }
      
      .mainbar table tr td {
      	font-family: 'Lucida Grande';
      	font-size: 12px;
      }

      .mainbar h2 {
      	font-family: 'Lucida Grande';
      	font-size: 16px;
      	color: #000000;
      	text-transform: uppercase;
      	margin: 10px 0 16px 0;
      }

      .mainbar h2 a {
      	font-family: 'Lucida Grande';
      	font-size: 16px;
      	color: #000000;
      	text-transform: uppercase;
      	text-decoration: none;
      	font-style: normal;
      }

      .mainbar a {
      	font-family: Georgia;
      	font-size: 13px;
      	color: #2679b9;
      	font-style: italic;
      }

      .mainbar a.center {
      	font-size: 12px;
      	text-align: center;
      	display: block;
      	color: #999999;
      	padding: 8px 0 12px 0;
      	text-decoration: none;
      }
   </style>

<div class="mainbar">
<h2>Website Response for "Request A Quote"</h2>
                  
<table width="100%" cellspacing="10" cellpadding="0">
	<tr>
	  <td align="right" valign="top"><strong>Name</strong></td>
	  <td><?= htmlentities($contact['name']) ?></td>
	</tr>
	<tr>
	  <td align="right" valign="top"><strong>Email</strong></td>
	  <td><?= htmlentities($contact['email']) ?></td>
	</tr>
	<tr>
	  <td align="right" valign="top"><strong>Message</strong></td>
	  <td><?= nl2br(htmlentities($contact['message'])) ?></td>
	</tr>
</table>

<p>&nbsp;</p>

<h2>Website User Information</h2>

<table width="100%" cellspacing="10" cellpadding="0">
	<tr>
	  <td align="right" valign="top" width="150"><strong>IP Address</strong></td>
	  <td><?= $contact['ip_address'] ?></td>
	</tr>
	<tr>
	  <td align="right" valign="top"><strong>URL</strong></td>
	  <td><?= $contact['current_url'] ?></td>
	</tr>
	<tr>
	  <td align="right" valign="top"><strong>Agent String</strong></td>
	  <td><?= $contact['agent_string'] ?></td>
	</tr>
	<tr>
	  <td align="right" valign="top"><strong>Platform</strong></td>
	  <td><?= $contact['agent_platform'] ?></td>
	</tr>
</table>
</div>