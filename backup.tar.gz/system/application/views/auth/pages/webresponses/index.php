<h1>
	Web Responses
</h1>

<?php include($this->config->item('full_path') . 'system/application/views/auth/flashdata.php'); ?>

<h4>
	Request A Quote
</h4>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
<thead>
	<tr>
		<th align="left">Name</th>
		<th width="250">Created</th>
		<th width="75">Action</th>
	</tr>
</thead>
<tbody>
<?php
if( count($webresponses) > 0 )
{
	foreach ($webresponses as $row)
	{
	?>
	<tr>
		<td>
			<?= htmlentities($row['name']); ?>
		</td>
		<td align="center">
			<?= timespan(mysql_to_unix($row['created_at']), now()) . " Ago"; ?>
		</td>
		<td align="center">
			<a class="button" href="/admin/webresponses/view/<?= $row['id']; ?>">View</a>
		</td>
	</tr>
	<?
	}
}
?>
	
</tbody>
</table>