<h1>
	Delete Setting "<?= $setting['name'] ?>"?
</h1>

<p align="center">
	<a class="button" href="/admin/settings/delete/<?= $setting['id'] ?>/confirm">Yes!</a>&nbsp;|&nbsp;<a class="button" href="/admin/settings">No, Thanks!</a>
</p>