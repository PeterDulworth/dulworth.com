<h1>
	Delete Testimonial "<?= $testimonial['name'] ?>"?
</h1>

<p align="center">
	<a class="button" href="/admin/testimonials/delete/<?= $testimonial['id'] ?>/confirm">Yes!</a>&nbsp;|&nbsp;<a class="button" href="/admin/testimonials">No, Thanks!</a>
</p>