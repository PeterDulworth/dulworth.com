<?php include($this->config->item('full_path') . 'system/application/views/auth/tinymce.php'); ?>

<h1>
	Edit Testimonial
</h1>

<?php echo validation_errors('<p class="error">', '</p>'); ?>
<?php echo form_open('admin/testimonials/edit/' . $testimonial['id']); ?>

	<div class="input_field">
		<label for="name" class="">Name</label>
	<div class="clear">&nbsp;</div>
		<input id="" class="input bigfield" type="text" name="name" value="<?php echo set_value('name', $testimonial['name']); ?>" />
	</div>
	<div class="clear">&nbsp;</div>
	
	<div class="input_field">
		<label for="testimonial" class="">Testimonial</label>
	<div class="clear">&nbsp;</div>
		<textarea id="" class="input textarea" name="testimonial"><?php echo set_value('testimonial', $testimonial['testimonial']); ?></textarea>
	</div>
	<div class="clear">&nbsp;</div>
	
	<div class="input_field">
		<label for="submit" class="">&nbsp;</label>
	<div class="clear">&nbsp;</div>
		<input class="submit" type="submit" name="submit" value="submit" />
	</div>
	<div class="clear">&nbsp;</div>
</form>