<h1>
	Manage Testimonials
</h1>

<?php include($this->config->item('full_path') . 'system/application/views/auth/flashdata.php'); ?>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
<thead>
	<tr>
		<th align="left">Name</th>
		<th width="250">Updated</th>
		<th width="100">Action</th>
	</tr>
</thead>
<tbody>
<?php
if( count($testimonials) > 0 )
{
	foreach ($testimonials as $row)
	{
	?>
	<tr>
		<td>
			<?= $row['name']; ?>
		</td>
		<td>
			<?= timespan(mysql_to_unix($row['updated_at']), now()) . " Ago"; ?>
		</td>
		<td align="center">
			<a class="button" href="/admin/testimonials/edit/<?= $row['id']; ?>">Edit</a>
			&nbsp;|&nbsp;
			<a class="button" href="/admin/testimonials/delete/<?= $row['id']; ?>">Delete</a>
		</td>
	</tr>
	<?
	}
}
?>
	<tr>
		<td class="tmenu" colspan="4" align="right">
			<?php echo anchor($this->config->item('auth_controllers_root') . "testimonials/add", "Add Testimonial"); ?>
		</td>
	</tr>
</tbody>
</table>