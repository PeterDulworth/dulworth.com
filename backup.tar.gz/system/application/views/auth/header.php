<?php echo doctype('xhtml-strict'); ?>

<html>
	<head>
		<?php echo meta('Content-type', 'text/html; charset=utf-8', 'equiv'); ?>
		
				
		<title>Dulworth &amp; Company Admin Panel</title>
	
		<?php echo link_tag('css/reset.css'); ?>
		
		<?php echo link_tag('css/text.css'); ?>
		
		<?php echo link_tag('css/960.css'); ?>
		
		<?php echo link_tag('css/style_admin.css'); ?>
		
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js"></script>
	</head>
	<body>
		<div class="container_12">
			<div id="header" class="grid_6">
				Dulworth &amp; Company Admin Panel
			</div>
			<!-- end .grid_6 -->
			<div id="usernav" class="grid_6">
				<?php
				if( logged_in() )
				{
				?>
				<strong>Welcome <?php echo username(); ?></strong> | (<?php echo anchor('admin/logout', 'Logout'); ?>)
				<?php
				}
				?>
			</div>
			<!-- end .grid_6 -->
			<div class="clear"></div>
			
			<div id="menunav" class="grid_12">
			<?php $this->load->view($this->config->item('auth_views_root') . 'nav'); ?>
			</div>
			<!-- end .grid_12 -->
			<div class="clear"></div>
			
			<div id="content" class="grid_12">