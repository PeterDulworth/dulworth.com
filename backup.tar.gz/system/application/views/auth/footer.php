			</div>
			<!-- end .grid_12 -->
			<div class="clear"></div>
			<div id="footer" class="grid_12">
					Copyright &copy; 2009 <a href="http://www.netmediapros.com">Net Media Pros, LLC</a>, All Rights Reserved.
			</div>
			<!-- end .grid_12 -->
			<div class="clear"></div>
		</div>
		<!-- end .container_12 -->
	</body>
</html>