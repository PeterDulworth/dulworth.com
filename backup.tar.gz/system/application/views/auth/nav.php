<ul id="navigation">
<?php
if( logged_in() )
{
?>
	<li><?php echo anchor('admin/dashboard', 'Dashboard'); ?></li>
	<li><?php if(user_group('admin')) { echo anchor('admin/users', 'Users'); } ?></li>
	<li><?php if(user_group('editor') || user_group('admin')) { echo anchor('admin/pages', 'Pages'); } ?></li>
	<li><?php //if(user_group('editor') || user_group('admin')) { echo anchor('admin/galleries', 'Galleries'); } ?></li>
	<li><?php //if(user_group('editor') || user_group('admin')) { echo anchor('admin/testimonials', 'Testimonials'); } ?></li>
	<li><?php if(user_group('editor') || user_group('admin')) { echo anchor('admin/webresponses', 'Web Responses'); } ?></li>
	<li><?php if(user_group('editor') || user_group('admin')) { echo anchor('admin/settings', 'Settings'); } ?></li>
<?php
} else
{
?>
	<li><?php echo anchor('admin/login', 'Login'); ?></li>
	<li><?php //echo anchor('register', 'Register'); ?></li>
<?php
}
?>
</ul>