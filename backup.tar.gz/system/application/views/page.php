               <!-- contents -->
                  <div class="contents">
                       <?php echo $page['content']; ?>
                       
                       <div class="clear"></div>
                  </div>
               <!-- contents -->
