<?php
if(count($pagelist) > 0)
{
?>
<ul>
	<?php
	foreach( $pagelist as $page )
	{
		$current = null;
		if( $page['url'] == uri_string() )
		{
			$current = ' class="selected"';
		}
	?>
	<li><a href="<?= $page['url']; ?>"<?= $current; ?>><?= $page['name']; ?></a></li>
	<?php
	}
	?>
</ul>
<?
}
?>