<?php
if( isset($home_content) )
{
?>
               <!-- 2 box div -->
                  <div class="holder">
                      <!-- legacy box -->
					  <?php echo $site_legacy; ?>
                      
                      <!-- bank box -->
                      <?php echo $site_identification; ?>
                      
                      <div class="clear"></div>
                  </div>
               <!-- 2 box div -->
<?php
}
?>               
				<div class="clear"></div>
               <!-- footer -->
                  <div class="footer">
	                  <?php echo $footer_address; ?>
	                  
	                  <div class="footRg">
	                      <a href="/contact-us" class="Achor">contact us&nbsp;</a>|<a href="/privacy-notice" class="Achor">privacy notice</a>
	                      <?php echo $footer_copyright; ?>
	
	                  </div>
	                  
	                  <div class="clear"></div>
                  </div>
               <!-- footer -->
             
           <!-- container  ends -->  
           </div>
      </div>
</div>
<div id="legal">
	<?php echo $footer_legal; ?>
</div>

<?php include('analytics.php'); ?>

<!-- Page rendered in {elapsed_time} seconds -->

</body>
</html>