<?=doctype('xhtml1-strict');?>

<html>
<head>
	<title><?=$meta_title; ?></title>
	
	<?=meta('Content-Type', 'text/html; charset=utf-8', 'equiv');?>
	<?=meta('description', $meta_desc);?>
	<?=meta('keywords', $meta_keywords);?>
	
	<?=link_tag('css/style.css');?>
	
	<?=link_tag('css/forms.css');?>
	
	<?=link_tag('css/jquery.lightbox-0.5.css');?>
	
	<!--[if IE 6]>
		<style>
	        .navMenu li .Ach{color:#dfd485;font-size:12px;line-height:20px;padding:0 13px 0 34px;}
			.welcome{width:366px;float:left;border:0px solid red;margin:10px 0 0 17px;line-height:13px;}
	        .address{float:left;color:#a8a8a8;font-size:12px;text-align:left;margin:14px 0 0 17px;line-height:14px;}
	        .footRg{float:right;text-align:right;margin-top:36px;margin-right:20px;}
	    </style>
	    <script type="text/javascript" src="supersleight-min.js"></script>
	<![endif]-->
	
	<!--[if IE 7]>
		<style>
	        .navMenu li .Ach{color:#dfd485;font-size:12px;line-height:20px;padding:0 13px 0 34px;}
	    </style>
	<![endif]-->
	
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
	<script type="text/javascript" src="/js/jquery.lightbox-0.5.pack.js"></script>
	<script type="text/javascript" src="/js/init.js"></script>
</head>

<body>
<div id="bigwrap">
<div id="wrapper">
<!-- wrapper begin here -->

        <!-- container -->
           <div class="container">
               
               <!-- logo top div -->
                  <div class="topDv">
                          <div class="logo">
                                 <div class="logoImg">
                                     <a href="#"><?php echo img('images/logo.png'); ?></a>
                                 </div>
                                 <p class="since">Since 1951</p>

                                 <div class="clear"></div>
                                 <p class="since2">Business, Estate &amp; Charitable Planning &bull; Employee &amp; Executive Benefits &bull; Life Insurance Brokerage</p>
                                
                          </div>
                          
                          <p class="number">
                            Phone: 713-222-1961<br />
                            Fax: 713-800-4125
                          </p>

                          
                          <div class="clear"></div>
                   </div>
               <!-- logo top div -->
               
               <!-- navidation -->
                  <div class="navigator">
                         <?php echo $menu; ?>
                         <?php /*
                         <ul class="navMenu">
                            <li><a href="#" class="Ach">A<span>BOUT</span> U<span>S</span></a></li>

                            <li><a href="#" class="Ach">S<span>ERVICES</span></a></li>
                            <li><a href="#" class="Ach">O<span>UR</span> T<span>EAM</span></a></li>
                            <li><a href="#" class="Ach">R<span>EFERENCES</span></a></li>
                         </ul>
                         */ ?>

                         <div class="clear"></div>
                  </div>
               <!-- navigation -->
