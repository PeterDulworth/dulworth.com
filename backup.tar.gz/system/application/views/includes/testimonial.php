<?php
// CHOOSE RANDOM NUMBER OUT OF ARRAY
$random = array_rand($testimonials);
?>
<div class="testimonial">
	<blockquote>
		<?= $testimonials[$random]['testimonial']; ?>
		<p align="right">
			<?= $testimonials[$random]['name']; ?>
		</p>
	</blockquote>	
	
</div>