<?php echo validation_errors('<p class="error">', '</p>'); ?>

<?php echo form_open(uri_string(), array('id' => 'contact')); ?>
	<fieldset>
		
		<!-- Name -->
		<div>
			<label for="name">Name</label>
			<input type="text" name="name" id="name" value="<?php echo set_value('name'); ?>" />
		</div>
		
		<!-- Email -->
		<div>
			<label for="email">Email</label>
			<input type="text" name="email" id="email" value="<?php echo set_value('email'); ?>" />
		</div>
		
		<!-- Message -->
		<div>
			<label for="message">Message</label>
			<textarea name="message" id="message" cols="30" rows="6"><?php echo set_value('message'); ?></textarea>
		</div>
		
		<!-- Controls -->
		<div class="controls">
			<input type="text" name="stop" id="stop" value="" />
			<input type="submit" name="submit" id="submit" value="Submit" />
		</div>
		
	</fieldset>
</form>