<div id="gallery">
	<?php
	if( count($images) > 0 )
	{
	?>
	<ul>
	<?php
	$clear = 0;
		foreach ($images as $row)
		{
			$clear++;
			echo "<li>" . anchor($row['image'], img(array('src' => $row['image_thumb'], 'height' => '120', 'width' => '120', 'title' => $row['name'])), array('title' => '<h5>' . $row['name'] . '</h5>' . htmlentities($row['description'], ENT_QUOTES))) . "<br />" . $row['name'] . "</li>";
			if( $clear == 4 )
			{
				echo '<div class="clear"></div>';
				$clear = 0;
			}
		}
	?>
	</ul>
	<div class="clear"></div>
	<?php
	}
	?>
</div>
