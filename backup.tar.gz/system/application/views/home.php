               <!-- contents -->
                  <div class="contents">
                       <?php echo $home_content; ?>
                       
                       <div class="clear"></div>
                  </div>
               <!-- contents -->
