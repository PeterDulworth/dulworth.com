<?php

class Webresponsemodel extends Model
{

    function Webresponsemodel()
    {
        parent::Model();
    }

	function contacts()
	{
		$this->db->select('*');
		$this->db->from('ci_wr_contact');
		$this->db->order_by("id", "desc"); 
		
		$query = $this->db->get();
		
		return $query->result_array();
	}
	
	function contact($id)
    {
    	$this->db->select('*');
		$this->db->from('ci_wr_contact');
		$this->db->where('id', $id);
		
		$query = $this->db->get();
		
		return $query->row_array();
    }
}