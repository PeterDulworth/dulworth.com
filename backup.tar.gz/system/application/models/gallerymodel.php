<?php

class Gallerymodel extends Model
{

    function Gallerymodel()
    {
        parent::Model();
    }

	function galleries()
	{
		$this->db->select('*');
		$this->db->from('ci_galleries');
		$this->db->order_by("name", "asc"); 
		
		$query = $this->db->get();
		
		return $query->result_array();
	}
	
	function gallery($id)
    {
    	$this->db->select('*');
		$this->db->from('ci_galleries');
		$this->db->where('id', $id);
		
		$query = $this->db->get();
		
		return $query->row_array();
    }
    
    function add($name)
	{
    	$this->db->set('name', $name);
		$this->db->set('created_at', date('Y-m-d H:i:s'));
		$this->db->insert('ci_galleries');
    }
	
	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('ci_galleries');
	}
	
	function edit($id, $name)
	{
		$this->db->set('name', $name);
		$this->db->where('id', $id);
		$this->db->update('ci_galleries');
	}
	
	function images($id)
	{
		$this->db->select('*');
		$this->db->from('ci_images');
		$this->db->where('parent_id', $id);
		$this->db->where('type', '2'); // type 2 is for gallery images
		$this->db->order_by('order', 'asc'); 
		
		$query = $this->db->get();
		
		return $query->result_array();
	}
	
	function image($id)
    {
    	$this->db->select('*');
		$this->db->from('ci_images');
		$this->db->where('id', $id);
		
		$query = $this->db->get();
		
		return $query->row_array();
    }
    
    function images_add($parent, $name, $description, $image, $image_thumb, $order)
	{
    	$this->db->set('type', '2'); // type 2 is for gallery images
    	$this->db->set('parent_id', $parent);
    	$this->db->set('name', $name);
    	$this->db->set('description', $description);
    	$this->db->set('image', $image);
    	$this->db->set('image_thumb', $image_thumb);
    	$this->db->set('order', $order);
    	
		$this->db->set('created_at', date('Y-m-d H:i:s'));
		
		$this->db->insert('ci_images');
    }
	
	function images_edit($id, $name, $description, $image, $imagethumb)
	{
		$this->db->set('name', $name);
    	$this->db->set('description', $description);
    	$this->db->set('image', $image);
    	$this->db->set('image_thumb', $image_thumb);
		$this->db->where('id', $id);
		$this->db->update('ci_images');
	}
	
	function images_delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('ci_images');
	}
}