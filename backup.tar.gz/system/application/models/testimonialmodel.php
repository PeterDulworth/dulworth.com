<?php

class Testimonialmodel extends Model
{

    function Testimonialmodel()
    {
        parent::Model();
    }

	function testimonials()
	{
		$this->db->select('*');
		$this->db->from('ci_testimonials');
		$this->db->order_by("name", "asc"); 
		
		$query = $this->db->get();
		
		return $query->result_array();
	}
	
	function testimonial($id)
    {
    	$this->db->select('*');
		$this->db->from('ci_testimonials');
		$this->db->where('id', $id);
		
		$query = $this->db->get();
		
		return $query->row_array();
    }
    
    function add($name, $testimonial, $date)
	{
    	$this->db->set('name', $name);
		$this->db->set('testimonial', $testimonial);
		$this->db->set('created_at', date('Y-m-d H:i:s'));
		$this->db->insert('ci_testimonials');
    }
	
	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('ci_testimonials');
	}
	
	function edit($id, $name, $testimonial)
	{
		$this->db->set('name', $name);
		$this->db->set('testimonial', $testimonial);
		$this->db->where('id', $id);
		$this->db->update('ci_testimonials');
	}
}