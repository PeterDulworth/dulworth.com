<?php

class Settingmodel extends Model
{

    function Settingmodel()
    {
        parent::Model();
    }

	function site_settings()
	{
		$this->db->select('*');
		$this->db->from('ci_config');
		$this->db->not_like('name', 'home_%');
		$this->db->order_by("name", "asc"); 
		
		$query = $this->db->get();
		
		return $query->result_array();
	}

	function home_settings()
	{
		$this->db->select('*');
		$this->db->from('ci_config');
		$this->db->like('name', 'home_%');
		$this->db->order_by("name", "asc"); 
		
		$query = $this->db->get();
		
		return $query->result_array();
	}
	
	function setting($id)
    {
    	$this->db->select('*');
		$this->db->from('ci_config');
		$this->db->where('id', $id);
		
		$query = $this->db->get();
		
		return $query->row_array();
    }
    
    function add($name, $value)
	{
    	$this->db->set('name', $name);
		$this->db->set('value', $value);
		$this->db->set('created_at', date('Y-m-d H:i:s'));
		$this->db->insert('ci_config');
    }
	
	function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('ci_config');
	}
	
	function edit($id, $name, $value)
	{
		$this->db->set('name', $name);
		$this->db->set('value', $value);
		$this->db->where('id', $id);
		$this->db->update('ci_config');
	}
}