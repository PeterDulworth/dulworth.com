<?php

class Pagemodel extends Model
{

    function Pagemodel()
    {
        parent::Model();
    }

	function pages()
	{
		$this->db->select('*');
		$this->db->from('ci_pages');
		$this->db->order_by("name", "asc"); 
		
		$query = $this->db->get();
		
		return $query->result_array();
	}
	
	function page($id)
    {
    	$this->db->select('
    		ci_pages.id,
    		ci_pages.status,
    		ci_pages.parent_id,
    		ci_pages.url_id,
    		ci_pages.name,
    		ci_pages.banner,
    		ci_pages.media,
    		ci_pages.content,
    		ci_pages.meta_title,
    		ci_pages.meta_desc,
    		ci_pages.meta_keywords,
    		ci_pages.meta_footer,
    		ci_pages.updated_at,
    		ci_urls.url,
    		ci_pages_order.value as page_order');
		$this->db->from('ci_pages');
		$this->db->join('ci_urls', 'ci_urls.id = ci_pages.url_id');
		$this->db->join('ci_pages_order', 'ci_pages_order.page_id = ci_pages.id');
		$this->db->where('ci_pages.id', $id);
		
		$query = $this->db->get();
		
		return $query->row_array();
    }
	
	function page_by_url($url)
    {
    	$this->db->select('
    		ci_pages.id,
    		ci_pages.status,
    		ci_pages.parent_id,
    		ci_pages.url_id,
    		ci_pages.name,
    		ci_pages.banner,
    		ci_pages.media,
    		ci_pages.content,
    		ci_pages.meta_title,
    		ci_pages.meta_desc,
    		ci_pages.meta_keywords,
    		ci_pages.meta_footer,
    		ci_pages.updated_at,
    		ci_urls.url,
    		ci_pages_order.value as page_order');
		$this->db->from('ci_pages');
		$this->db->join('ci_urls', 'ci_urls.id = ci_pages.url_id');
		$this->db->join('ci_pages_order', 'ci_pages_order.page_id = ci_pages.id');
		$this->db->where('ci_urls.url', $url);
		
		$query = $this->db->get();
		
		return $query->row_array();
    }
    
    function parent_pages($parent_id)
    {
    	$this->db->select('
    		ci_pages.id,
    		ci_pages.status,
    		ci_pages.parent_id,
    		ci_pages.url_id,
    		ci_pages.name,
    		ci_pages.banner,
    		ci_pages.media,
    		ci_pages.content,
    		ci_pages.meta_title,
    		ci_pages.meta_desc,
    		ci_pages.meta_keywords,
    		ci_pages.meta_footer,
    		ci_pages.updated_at,
    		ci_urls.url,
    		ci_pages_order.value as page_order');
		$this->db->from('ci_pages');
		$this->db->join('ci_urls', 'ci_urls.id = ci_pages.url_id');
		$this->db->join('ci_pages_order', 'ci_pages_order.page_id = ci_pages.id');
		$this->db->where('ci_pages.parent_id', $parent_id);
		$this->db->order_by("page_order", "asc");
		$this->db->order_by("name", "asc");
		
		$query = $this->db->get();
		
		return $query->result_array();
    }
}