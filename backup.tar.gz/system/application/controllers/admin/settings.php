<?php

class Settings extends Application
{
	
	function Settings()
	{
		parent::Application();
		$this->auth->restrict('editor'); // restrict this controller to admins only
		$this->load->model($this->models."settingmodel", 'settings'); // Load the testimonial model
	}
	
	function index()
	{
		$data['settings'] = $this->settings->site_settings();
		
		$this->auth->view('settings/index', $data); // Load the view
	}
	
	function add()
	{
		$this->form_validation->set_rules('name', 'Name', 'trim|required');
		
		if ($this->form_validation->run() == FALSE)
		{
			$this->auth->view('settings/add'); // Load the view
		}
		else
		{
			$this->settings->add($this->input->post('name'), $this->input->post('value'));
			
			$this->session->set_flashdata('success', 'The setting "' . $this->input->post('name') . '" has been added');
			
			redirect('admin/settings');
		}
	}
	
	function delete($id)
	{
		if( $this->uri->segment(4) == FALSE )
		{
			redirect('admin/settings');
		}
		
		$data['setting'] = $this->settings->setting($this->uri->segment(4));
		
		if( $this->uri->segment(5) == FALSE )
		{
			$this->auth->view('settings/delete', $data); // Load the view
		}
		elseif( $this->uri->segment(5) == "confirm" )
		{
			$this->settings->delete($this->uri->segment(4));
			
			$this->session->set_flashdata('success', 'The setting "' . $data['setting']['name'] . '" has been deleted');
			
			redirect('admin/settings');
		}
	}
	
	function edit($id)
	{
		if($this->uri->segment(4) == FALSE)
		{
			redirect('admin/settings');
		}
		
		$data['setting'] = $this->settings->setting($this->uri->segment(4));
		
		$this->form_validation->set_rules('name', 'Name', 'trim|required');
		
		if ($this->form_validation->run() == FALSE)
		{
			$this->auth->view('settings/edit', $data); // Load the view
		}
		else
		{
			$this->settings->edit($this->uri->segment(4), $this->input->post('name'), $this->input->post('value'));
						
			$this->session->set_flashdata('success', 'The setting "' . $this->input->post('name') . '" has been updated');
			
			if (strstr($data['setting']['name'], 'home_'))
			{
			    redirect('admin/pages');
			} else
			{
				redirect('admin/settings');
			}
		}
	}
}