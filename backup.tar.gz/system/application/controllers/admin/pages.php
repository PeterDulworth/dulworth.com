<?php

class Pages extends Application
{
	
	function Pages()
	{
		parent::Application();
		$this->auth->restrict('editor'); // restrict this controller to admins only
		$this->load->model($this->models."pagemodel", 'pages'); // Load the page model - gets lists of pages etc
		$this->load->model($this->models."gallerymodel", 'galleries');
	}
	
	function index()
	{
		$data['pages'] = $this->_format_page_list();
		$data['pages_noparent'] = $this->pages->parent_pages("1000");
		
		$this->load->model($this->models."settingmodel", 'settings'); // Load the setting model
		$data['settings'] = $this->settings->home_settings();
		
		$this->auth->view('pages/index', $data); // Load the view
	}
	
	function add()
	{
		$data['sitetree'] = $this->_format_page_list();
		$data['galleries'] = $this->galleries->galleries();
		
		$this->form_validation->set_rules('parent_id', 'Parent ID', 'trim');
		$this->form_validation->set_rules('url_id', 'URL ID', 'trim');
		$this->form_validation->set_rules('name', 'Name', 'trim|required');
		$this->form_validation->set_rules('banner', 'Banner Image', 'trim');
		$this->form_validation->set_rules('media', 'Media', 'trim');
		$this->form_validation->set_rules('content', 'Content', 'trim');
		$this->form_validation->set_rules('meta_title', 'Meta Title', 'trim');
		$this->form_validation->set_rules('meta_desc', 'Meta Description', 'trim');
		$this->form_validation->set_rules('meta_keywords', 'Meta Keywords', 'trim');
		$this->form_validation->set_rules('meta_footer', 'Meta Footer', 'trim');
		
		if ($this->form_validation->run() == FALSE)
		{
			$this->auth->view('pages/add', $data); // Load the view
		}
		else
		{
			// Find/Set Page Order Value
			$pages = $this->pages->parent_pages($this->input->post('parent_id'));
			if( count($pages) > 0 )
			{
				foreach( $pages as $page )
				{
					$value = $page['page_order'] + 10;
				}
			}else
			{
				$value = 10;
			}
			
			$url = $this->_format_url($this->input->post('name'), $this->input->post('parent_id'));
			
			// Insert URL
			$this->db->set('url', $url);
			$this->db->set('type', '2');
			$this->db->set('created_at', date('Y-m-d H:i:s'));
			$this->db->insert('ci_urls');
			
			// Get URL ID
			$url_id = $this->db->insert_id();
			
			// Insert Page
			$this->db->set('parent_id', $this->input->post('parent_id'));
			$this->db->set('url_id', $url_id);
			$this->db->set('name', $this->input->post('name'));
			$this->db->set('banner', $this->input->post('banner'));
			$this->db->set('media', $this->input->post('media'));
			$this->db->set('content', $this->input->post('content'));
			$this->db->set('meta_title', $this->input->post('meta_title'));
			$this->db->set('meta_desc', $this->input->post('meta_desc'));
			$this->db->set('meta_keywords', $this->input->post('meta_keywords'));
			$this->db->set('meta_footer', $this->input->post('meta_footer'));
			$this->db->set('created_at', date('Y-m-d H:i:s'));
			$this->db->insert('ci_pages');
			
			// Get Page ID
			$page_id = $this->db->insert_id();
			
			// Insert Page Order
			$this->db->set('page_id', $page_id);
			$this->db->set('value', $value);
			$this->db->set('created_at', date('Y-m-d H:i:s'));
			$this->db->insert('ci_pages_order');
			
			$this->session->set_flashdata('success', 'The page "' . $this->input->post('name') . '" has been added');
			
			redirect('admin/pages');
		}
	}
	
	function delete($id)
	{
		if( $this->uri->segment(4) == FALSE )
		{
			redirect('admin/pages');
		}
		
		$page = $this->pages->page($this->uri->segment(4));
		
		if( $this->pages->parent_pages($page['id']) )
		{
			$this->session->set_flashdata('error', 'The page "' . $page['name'] . '" cannot be deleted, please remove/move the subpages to delete this page');
		
			redirect('admin/pages');
		}
		
		if( $this->uri->segment(5) == FALSE )
		{
			$data['page'] = $page;
			
			$this->auth->view('pages/delete', $data); // Load the view
		}
		elseif( $this->uri->segment(5) == "confirm" )
		{
			$this->db->where('id', $page['url_id']);
			$this->db->delete('ci_urls');
			
			$this->db->where('page_id', $this->uri->segment(4));
			$this->db->delete('ci_pages_order');
			
			$this->db->where('id', $this->uri->segment(4));
			$this->db->delete('ci_pages');
			
			$this->_format_page_order($page['parent_id']);
			
			$this->session->set_flashdata('success', 'The page "' . $page['name'] . '" has been deleted');
			
			redirect('admin/pages');
		}
	}
	
	function edit($id)
	{
		if($this->uri->segment(4) == FALSE)
		{
			redirect('admin/pages');
		}
		
		$data['sitetree'] = $this->_format_page_list($this->uri->segment(4));
		$data['page'] = $this->pages->page($this->uri->segment(4));
		$data['page_move_limit'] = $this->_get_page_move_limit($this->uri->segment(4));
		$data['galleries'] = $this->galleries->galleries();
		
		$this->form_validation->set_rules('parent_id', 'Parent ID', 'trim');
		$this->form_validation->set_rules('name', 'Name', 'trim|required');
		$this->form_validation->set_rules('banner', 'Banner Image', 'trim');
		$this->form_validation->set_rules('media', 'Media', 'trim');
		$this->form_validation->set_rules('content', 'Content', 'trim');
		$this->form_validation->set_rules('meta_title', 'Meta Title', 'trim');
		$this->form_validation->set_rules('meta_desc', 'Meta Description', 'trim');
		$this->form_validation->set_rules('meta_keywords', 'Meta Keywords', 'trim');
		$this->form_validation->set_rules('meta_footer', 'Meta Footer', 'trim');
		
		if ($this->form_validation->run() == FALSE)
		{
			$this->auth->view('pages/edit', $data); // Load the view
		}
		else
		{
			if( $data['page']['parent_id'] != '1000' )
			{
				// If Changing Parent, put at bottom of new parent
				if( $data['page']['parent_id'] != $this->input->post('parent_id') )
				{
					// Find/Set Page Order Value
					$pages = $this->pages->parent_pages($this->input->post('parent_id'));
					if( count($pages) > 0 )
					{
						foreach( $pages as $page )
						{
							$value = $page['page_order'] + 10;
						}
					}else
					{
						$value = 10;
					}
					
					// Update Page Order
					$this->db->set('value', $value);
					$this->db->where('page_id', $data['page']['id']);
					$this->db->update('ci_pages_order');
				}
				
				$this->db->set('parent_id', $this->input->post('parent_id'));
			}
			$this->db->set('name', $this->input->post('name'));
			$this->db->set('banner', $this->input->post('banner'));
			$this->db->set('media', $this->input->post('media'));
			$this->db->set('content', $this->input->post('content'));
			$this->db->set('meta_title', $this->input->post('meta_title'));
			$this->db->set('meta_desc', $this->input->post('meta_desc'));
			$this->db->set('meta_keywords', $this->input->post('meta_keywords'));
			$this->db->set('meta_footer', $this->input->post('meta_footer'));
			$this->db->where('id', $data['page']['id']);
			$this->db->update('ci_pages');
			
			$url = $this->_format_url($this->input->post('name'), $this->input->post('parent_id'));
			
			$this->db->set('url', $url);
			$this->db->where('id', $data['page']['url_id']);
			$this->db->update('ci_urls');
			
			// Fix All Subpage URL References
			if( $data['page']['url'] != $url )
			{
				$pages = $this->pages->parent_pages($data['page']['id']);
				if( count($pages) > 0 )
				{
					foreach( $pages as $page )
					{
						$this->db->set('url', $this->_format_url($page['name'], $page['parent_id']));
						$this->db->where('id', $page['url_id']);
						$this->db->update('ci_urls');
						
						$subpages1 = $this->pages->parent_pages($page['id']);
						if( count($subpages1) > 0 )
						{
							foreach( $subpages1 as $subpage1 )
							{
								$this->db->set('url', $this->_format_url($subpage1['name'], $subpage1['parent_id']));
								$this->db->where('id', $subpage1['url_id']);
								$this->db->update('ci_urls');
							}
						}
					}
				}
			}
			
			//Reorder Old Parent Subpages
			$this->_format_page_order($data['page']['parent_id']);
			$this->_format_page_order($this->input->post('parent_id'));
			
			$this->session->set_flashdata('success', 'The page "' . $this->input->post('name') . '" has been updated');
			
			redirect('admin/pages');
		}
	}
	
	function move()
	{
		if($this->uri->segment(4) == FALSE || $this->uri->segment(5) == FALSE)
		{
			redirect('admin/pages');
		}
		
		$direction = $this->uri->segment(4);
		$page = $this->pages->page($this->uri->segment(5));
		
		if( $direction == "up" )
		{
			$page['page_order'] = $page['page_order'] - 11;
		} elseif( $direction == "down" )
		{
			
			$page['page_order'] = $page['page_order'] + 11;
		}else
		{
			$this->session->set_flashdata('error', 'Requested action is invalid');
			redirect('admin/pages');
		}
		
		$this->db->set('value', $page['page_order']);
		$this->db->where('page_id', $page['id']);
		$this->db->update('ci_pages_order');
		
		// RE-ORDER ALL PAGES FOR PARENT_ID
		
		$this->_format_page_order($page['parent_id']);
		
		$this->session->set_flashdata('success', 'The page "' . $page['name'] . '" has been moved');
		redirect('admin/pages');
	}
	
	function _format_page_list($exclude=null)
	{
		$pages = $this->pages->parent_pages("0");
		
		if( $exclude )
		{
			$exclude = $this->pages->page($exclude);
		}
		
		if( count($pages) > 0 )
		{
			foreach( $pages as $page )
			{
				$page['level'] = "0";
				if( $exclude['id'] != $page['id'] )
				{
					$pagelist[] = $page;
							
					if( $this->pages->parent_pages($page['id']) )
					{
						foreach( $this->pages->parent_pages($page['id']) as $subpage1 )
						{
							$subpage1['level'] = "5";
							if( $exclude['id'] != $subpage1['id'] )
							{
								$pagelist[] = $subpage1;
								
								if( $this->pages->parent_pages($subpage1['id']) )
								{
									foreach( $this->pages->parent_pages($subpage1['id']) as $subpage2 )
									{
										$subpage2['level'] = "10";
										if( $exclude['id'] != $subpage2['id'] )
										{
											$pagelist[] = $subpage2;
										}
									}
								}
							}
						}
					}
				}
			}
			
			return $pagelist;
		}
		
		return null;
	}
	
	function _format_url($name, $parent_id)
	{
		// Set Initial URL
		$url = "/" . url_title($name, 'dash', TRUE);
		// Find Parents
		if( $parent_id > '0' )
		{
			$parent1 = $this->pages->page($parent_id);
			$url = "/" . url_title($parent1['name'], 'dash', TRUE) . $url;
			
			if( $parent1['parent_id'] > '0' )
			{
				$parent2 = $this->pages->page($parent1['parent_id']);
				$url = "/" . url_title($parent2['name'], 'dash', TRUE) . $url;
			}
		}
		
		return $url;
	}
	
	function _get_page_move_limit($id)
	{
		$limit = 10;
		// Find Subpages of Page
		$subpages1 = $this->pages->parent_pages($id);
		if( count($subpages1) > 0 )
		{
			$limit = 5;
			
			foreach( $subpages1 as $subpage1 )
			{
				$subpages2 = $this->pages->parent_pages($subpage1['id']);
				if( count($subpages2) > 0 )
				{
					$limit = 0;
					
					//Should be MAX Limit allowed.
				}
			}
			
		}
		
		return $limit;
	}
	
	function _format_page_order($parent_id)
	{
		$pages = $this->pages->parent_pages($parent_id);
		
		$count = 10;
		foreach( $pages as $page )
		{
			$this->db->set('value', $count);
			$this->db->where('page_id', $page['id']);
			$this->db->update('ci_pages_order');
			
			$count = $count + 10;
		}
	}
}