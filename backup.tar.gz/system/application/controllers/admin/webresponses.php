<?php

class Webresponses extends Application
{
	
	function Webresponses()
	{
		parent::Application();
		$this->auth->restrict('editor'); // restrict this controller to admins only
		$this->load->model($this->models."webresponsemodel", 'webresponses'); // Load the testimonial model
	}
	
	function index()
	{
		$data['webresponses'] = $this->webresponses->contacts();
		
		$this->auth->view('webresponses/index', $data); // Load the view
	}
	
	function view($id)
	{
		if($this->uri->segment(4) == FALSE)
		{
			redirect('admin/webresponses');
		}
		
		$data['contact'] = $this->webresponses->contact($this->uri->segment(4));
		
		$this->auth->view('webresponses/view', $data); // Load the view
	}
}