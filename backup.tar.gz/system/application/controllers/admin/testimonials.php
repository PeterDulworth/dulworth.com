<?php

class Testimonials extends Application
{
	
	function Testimonials()
	{
		parent::Application();
		$this->auth->restrict('editor'); // restrict this controller to admins only
		$this->load->model($this->models."testimonialmodel", 'testimonials'); // Load the testimonial model
	}
	
	function index()
	{
		$data['testimonials'] = $this->testimonials->testimonials();
		
		$this->auth->view('testimonials/index', $data); // Load the view
	}
	
	function add()
	{
		$this->form_validation->set_rules('name', 'Name', 'trim|required');
		$this->form_validation->set_rules('testimonial', 'Testimonial', 'trim|required');
		
		if ($this->form_validation->run() == FALSE)
		{
			$this->auth->view('testimonials/add'); // Load the view
		}
		else
		{
			$this->testimonials->add($this->input->post('name'), $this->input->post('testimonial'));
			
			$this->session->set_flashdata('success', 'The testimonial "' . $this->input->post('name') . '" has been added');
			
			redirect('admin/testimonials');
		}
	}
	
	function delete($id)
	{
		if( $this->uri->segment(4) == FALSE )
		{
			redirect('admin/testimonials');
		}
		
		$data['testimonial'] = $this->testimonials->testimonial($this->uri->segment(4));
		
		if( $this->uri->segment(5) == FALSE )
		{
			$this->auth->view('testimonials/delete', $data); // Load the view
		}
		elseif( $this->uri->segment(5) == "confirm" )
		{
			$this->testimonials->delete($this->uri->segment(4));
			
			$this->session->set_flashdata('success', 'The testimonial "' . $data['testimonial']['name'] . '" has been deleted');
			
			redirect('admin/testimonials');
		}
	}
	
	function edit($id)
	{
		if($this->uri->segment(4) == FALSE)
		{
			redirect('admin/testimonials');
		}
		
		$data['testimonial'] = $this->testimonials->testimonial($this->uri->segment(4));
		
		$this->form_validation->set_rules('name', 'Name', 'trim|required');
		$this->form_validation->set_rules('testimonial', 'Testimonial', 'trim|required');
		
		if ($this->form_validation->run() == FALSE)
		{
			$this->auth->view('testimonials/edit', $data); // Load the view
		}
		else
		{
			$this->testimonials->edit($this->uri->segment(4), $this->input->post('name'), $this->input->post('testimonial'));
						
			$this->session->set_flashdata('success', 'The testimonial "' . $this->input->post('name') . '" has been updated');
			
			redirect('admin/testimonials');
		}
	}
}