<?php

class galleries extends Application
{
	
	function galleries()
	{
		parent::Application();
		$this->auth->restrict('editor');
		$this->load->model($this->models."gallerymodel", 'galleries');
	}
	
	function index()
	{
		$data['galleries'] = $this->galleries->galleries();
		
		$this->auth->view('galleries/index', $data); // Load the view
	}
	
	function add()
	{
		$this->form_validation->set_rules('name', 'Name', 'trim|required');
		
		if ($this->form_validation->run() == FALSE)
		{
			$this->auth->view('galleries/add'); // Load the view
		}
		else
		{
			$this->galleries->add($this->input->post('name'));
			
			mkdir('./assets/images/galleries/' . $this->db->insert_id());
			chmod('./assets/images/galleries/' . $this->db->insert_id(), 0777);
			
			$this->session->set_flashdata('success', 'The gallery "' . $this->input->post('name') . '" has been added');
			
			redirect('admin/galleries');
		}
	}
	
	function delete($id)
	{
		if( $this->uri->segment(4) == FALSE )
		{
			redirect('admin/galleries');
		}
		
		$data['gallery'] = $this->galleries->gallery($this->uri->segment(4));
		
		if( $this->uri->segment(5) == FALSE )
		{
			$this->auth->view('galleries/delete', $data); // Load the view
		}
		elseif( $this->uri->segment(5) == "confirm" )
		{
			$this->galleries->delete($this->uri->segment(4));
			
			$this->session->set_flashdata('success', 'The gallery "' . $data['gallery']['name'] . '" has been deleted');
			
			redirect('admin/galleries');
		}
	}
	
	function edit($id)
	{
		if($this->uri->segment(4) == FALSE)
		{
			redirect('admin/galleries');
		}
		
		$data['gallery'] = $this->galleries->gallery($this->uri->segment(4));
		
		$this->form_validation->set_rules('name', 'Name', 'trim|required');
		
		if ($this->form_validation->run() == FALSE)
		{
			$this->auth->view('galleries/edit', $data); // Load the view
		}
		else
		{
			$this->galleries->edit($this->uri->segment(4), $this->input->post('name'));
						
			$this->session->set_flashdata('success', 'The gallery "' . $this->input->post('name') . '" has been updated');
			
			redirect('admin/galleries');
		}
	}
	
	function images()
	{
		if($this->uri->segment(4) == FALSE)
		{
			redirect('admin/galleries');
		}
		
		$data['gallery'] = $this->galleries->gallery($this->uri->segment(4));
		$data['images'] = $this->galleries->images($this->uri->segment(4));
		
		$this->auth->view('galleries/images_index', $data); // Load the view
	}
	
	function images_add()
	{
		if($this->uri->segment(4) == FALSE)
		{
			redirect('admin/galleries');
		}
		
		$this->form_validation->set_rules('name', 'Name', 'trim|required');
		$this->form_validation->set_rules('image', 'Image', 'trim|required');
		$this->form_validation->set_rules('image_thumb', 'Image Thumbnail', 'trim|required');
		$this->form_validation->set_rules('description', 'Description', 'trim');
		
		if ($this->form_validation->run() == FALSE)
		{
			
			$this->auth->view('galleries/images_add');
		}
		else
		{
			$images = $this->galleries->images($this->uri->segment(4));
			
			if( count($images) > 0 )
			{
				foreach( $images as $image )
				{
					$order = $image['order'] + 10;
				}
			}else
			{
				$order = 10;
			}
			
			$this->galleries->images_add(
				$this->uri->segment(4),
				$this->input->post('name'),
				$this->input->post('description'),
				$this->input->post('image'),
				$this->input->post('image_thumb'),
				$order
			);
			
			$this->session->set_flashdata('success', 'The image "' . $this->input->post('name') . '" has been added.');
			
			redirect('admin/galleries/images/' . $this->uri->segment(4));
		}
	}
	
	function images_edit()
	{
		if($this->uri->segment(4) == FALSE)
		{
			redirect('admin/galleries');
		}
		
		$data['image'] = $this->galleries->image($this->uri->segment(4));
		
		$this->form_validation->set_rules('name', 'Name', 'trim|required');
		$this->form_validation->set_rules('image', 'Image', 'trim|required');
		$this->form_validation->set_rules('image_thumb', 'Image Thumbnail', 'trim|required');
		$this->form_validation->set_rules('description', 'Description', 'trim');
		
		if ($this->form_validation->run() == FALSE)
		{
			$this->auth->view('galleries/images_edit', $data); // Load the view
		}
		else
		{
			$this->galleries->images_edit(
				$this->uri->segment(4),
				$this->input->post('name'),
				$this->input->post('description'),
				$this->input->post('image'),
				$this->input->post('image_thumb')
			);
						
			$this->session->set_flashdata('success', 'The gallery "' . $this->input->post('name') . '" has been updated');
			
			redirect('admin/galleries/images/' . $data['image']['parent_id']);
		}
	}
	
	function images_delete()
	{
		if($this->uri->segment(4) == FALSE)
		{
			redirect('admin/galleries');
		}
		
		$data['image'] = $this->galleries->image($this->uri->segment(4));
		
		if( $this->uri->segment(5) == FALSE )
		{
			$this->auth->view('galleries/images_delete', $data); // Load the view
		}
		elseif( $this->uri->segment(5) == "confirm" )
		{
			$this->galleries->images_delete($this->uri->segment(4));
			
			$this->session->set_flashdata('success', 'The image "' . $data['image']['name'] . '" has been deleted');
			
			redirect('admin/galleries/images/' . $data['image']['parent_id']);
		}
	}
	
	function images_move()
	{
		if($this->uri->segment(4) == FALSE || $this->uri->segment(5) == FALSE)
		{
			redirect('admin/galleries');
		}
		
		$direction = $this->uri->segment(4);
		$image = $this->galleries->image($this->uri->segment(5));
		
		if( $direction == "up" )
		{
			$image['order'] = $image['order'] - 11;
		} elseif( $direction == "down" )
		{
			
			$image['order'] = $image['order'] + 11;
		}else
		{
			$this->session->set_flashdata('error', 'Requested action is invalid');
			redirect('admin/galleries/images/' . $image['parent_id']);
		}
		
		$this->db->set('order', $image['order']);
		$this->db->where('id', $image['id']);
		$this->db->update('ci_images');
		
		// RE-ORDER ALL PAGES FOR PARENT_ID
		
		$this->_format_image_order($image['parent_id']);
		
		$this->session->set_flashdata('success', 'The image "' . $image['name'] . '" has been moved');
		redirect('admin/galleries/images/' . $image['parent_id']);
	}
	
	function _format_image_order($parent_id)
	{
		$images = $this->galleries->images($parent_id);
		
		$count = 10;
		foreach( $images as $image )
		{
			$this->db->set('order', $count);
			$this->db->where('id', $image['id']);
			$this->db->update('ci_images');
			
			$count = $count + 10;
		}
	}
}