<?php

class Admin extends Application
{
	function Admin()
	{
		parent::Application();
	}
	
	function index()
	{
		if(logged_in())
		{
			$data['page_title'] = "Dashboard";
			
			$this->auth->view('dashboard', $data);
		}
		else
		{
			$this->auth->login();
		}
	}
	
	function register()  // CREATED TO OVERWRITE AUTH LIBRARY REGISTER FUNCTION
	{
		log_message('error', 'Register attempt by ' . $this->input->ip_address() . ' - ' . $this->input->user_agent());
		redirect('admin');
	}

}

/* End of file: dashboard.php */
/* Location: application/controllers/admin/dashboard.php */