<?php

class Main extends Controller {

	function Main()
	{
		parent::Controller();
		$this->load->model("pagemodel", 'pages');
	}
	
	function index()
	{
		$this->db->select('url, type');
		$this->db->from('ci_urls');
		$this->db->where('url', $this->uri->uri_string());
		
		$query = $this->db->get();
		$row = $query->row_array();
		
		if( $this->uri->segment(1) )
		{
			if( $query->num_rows() == 0 )
			{
				show_404(current_url());
			} else if( $query->num_rows() == 1 )
			{
				switch($row['type'])
				{
					case "1":
						$this->_home_view();
						break;
					case "2":
						$this->_page_view();
						break;
					default:
						show_404(current_url());
						break;
				}
			} else if( $query->num_rows() > 1 )
			{
				show_404(current_url());
			}
		} else
		{
			$this->_home_view();
		}
		
	}
	
	function _home_view()
	{
		$data['meta_title'] = $this->_format_meta_title($this->_get_config('meta_title'));
		$data['meta_desc'] = $this->_format_meta_desc($this->_get_config('meta_desc'));
		$data['meta_keywords'] = $this->_format_meta_keywords($this->_get_config('meta_keywords'));
		$data['meta_footer'] = $this->_format_meta_footer($this->_get_config('meta_footer'));
		$data['analytics'] = $this->_get_config('analytics');
		$data['footer_copyright'] = $this->_get_config('footer_copyright');
		$data['footer_address'] = $this->_get_config('footer_address');
		$data['footer_legal'] = $this->_get_config('footer_legal');
		$data['site_legacy'] = $this->_get_config('site_legacy');
		$data['site_identification'] = $this->_get_config('site_identification');
		
		$data['home_content'] = $this->_get_config('home_content');
		
		$data['menu'] = $this->_format_page_list();
		
		$this->load->view('includes/header', $data);
		$this->load->view('home', $data);
		$this->load->view('includes/footer', $data);
	}
	
	function _page_view()
	{
		$this->db->select('ci_pages.id, ci_pages.name, ci_pages.banner, ci_pages.content, ci_pages.media, ci_pages.meta_title, ci_pages.meta_desc, ci_pages.meta_keywords, ci_pages.meta_footer, ci_urls.url');
		$this->db->from('ci_pages');
		$this->db->join('ci_urls', 'ci_urls.id = ci_pages.url_id', 'left');
		$this->db->where('ci_urls.url', $this->uri->uri_string());
		
		$query = $this->db->get();
		
		$data['page'] = $query->row_array(); // Get Page Data from Database
		$data['page']['content'] = $this->_format_page_content($data['page']['content']); // Format Page Content with str_ireplace Function
		$data['meta_title'] = $this->_format_meta_title($data['page']['meta_title']);
		$data['meta_desc'] = $this->_format_meta_desc($data['page']['meta_desc']);
		$data['meta_keywords'] = $this->_format_meta_keywords($data['page']['meta_keywords']);
		$data['meta_footer'] = $this->_format_meta_footer($data['page']['meta_footer']);
		$data['analytics'] = $this->_get_config('analytics');
		$data['footer_copyright'] = $this->_get_config('footer_copyright');
		$data['footer_address'] = $this->_get_config('footer_address');
		$data['footer_legal'] = $this->_get_config('footer_legal');
		$data['site_legacy'] = $this->_get_config('site_legacy');
		$data['site_identification'] = $this->_get_config('site_identification');
		
		$this->load->model("pagemodel", 'pages'); // Load the page model - gets lists of pages etc
		$subnav_page = $this->pages->page_by_url("/" . $this->uri->segment(1));
		$data['subnav'] = $this->_get_subnav($subnav_page['id']);
		
		if( $data['page']['media'] == 0 )
		{
			// do nothing
		} elseif( $data['page']['media'] > 0 && $data['page']['media'] < 1000 )
		{
			// do nothing
			//$data['slideshow'] = $this->_display_slideshow($data['page']['media']);
		} elseif( $data['page']['media'] > 1000 )
		{
			// display gallery
			// SEARCH AND REPLACE CONTENT VARIABLES
			$search = array("<p>%gallery%</p>");
			$replace = array($this->_display_gallery($data['page']['media']));
			
			$data['page']['content'] = str_replace($search, $replace, $data['page']['content']);
		}
		
		$data['menu'] = $this->_format_page_list();
		
		$this->load->view('includes/header', $data);
		$this->load->view('page', $data);
		$this->load->view('includes/footer', $data);
	}
	
	function _get_config($name)
	{
		$this->db->select('name, value');
		$this->db->from('ci_config');
		$this->db->where('name', $name);
		
		$query = $this->db->get();
		
		$row = $query->row();
		
		return $row->value;
	}
	
	function _get_subnav($parent_id)
	{
		$pages = $this->pages->parent_pages($parent_id);
		
		if( count($pages) > 0 )
		{
			foreach( $pages as $page )
			{
				$data['pagelist'][] = $page;
			}
			return $this->load->view('includes/subnav',$data,TRUE);
		}
		return null;
	}
	
	function _format_page_content($page_content)
	{
		// SEARCH AND REPLACE CONTENT VARIABLES
		$search = array("<p>%sitemap%</p>", "<p>%testimonial%</p>", "<p>%contact_form%</p>");
		$replace = array($this->_display_sitemap(), $this->_display_testimonial(), $this->_display_contact_form());
		
		return str_replace($search, $replace, $page_content);
	}
	
	function _display_sitemap()
	{
		$this->db->select('ci_pages.id, ci_pages.parent_id, ci_pages.name, ci_urls.url');
		$this->db->from('ci_pages');
		$this->db->join('ci_urls', 'ci_urls.id = ci_pages.url_id');
		$this->db->where('ci_pages.parent_id', '0');
		$this->db->order_by("ci_pages.name", "asc");
		
		$query = $this->db->get();
		
		$result = "<ul>\n";
		foreach ($query->result_array() as $row)
		{
			$result .= "<li><a href=\"" . $row['url'] . ".html\">" . $row['name'] . "</a></li>\n";
			
			$this->db->select('ci_pages.id, ci_pages.parent_id, ci_pages.name, ci_urls.url');
			$this->db->from('ci_pages');
			$this->db->join('ci_urls', 'ci_urls.id = ci_pages.url_id');
			$this->db->where('ci_pages.parent_id', $row['id']);
			$this->db->order_by("ci_pages.name", "asc");
			
			$query = $this->db->get();
			
			if ($query->num_rows() > 0)
			{
				$result .= "<ul>\n";
				foreach ($query->result_array() as $row)
				{
				   $result .= "<li><a href=\"" . $row['url'] . ".html\">" . $row['name'] . "</a></li>\n";
				}
				$result .= "</ul>\n";
			}
		}
		$result .= "</ul>\n";
		
		return $result;
	}
	
	function _display_testimonial()
	{
		$this->load->model("testimonialmodel", 'testimonials'); // Load the testimonial model
		
		$data['testimonials'] = $this->testimonials->testimonials();
		
		if( count($data['testimonials']) > 0 )
		{
			return $this->load->view('includes/testimonial',$data,TRUE);
		} else
		{
			return null;
		}
	}
	
	function _display_contact_form()
	{
		// HONEYPOT
		if( $this->input->post('stop') != "" )
		{
			show_404("BOT(Contact Us Form) - " . $this->input->ip_address() . " - " . $this->input->user_agent());
			die();
		}
		
		$this->form_validation->set_rules('name', 'Name', 'trim|required');
		$this->form_validation->set_rules('email', 'Email', 'trim|valid_email|required');
		$this->form_validation->set_rules('message', 'Message', 'trim');
		
		if ($this->form_validation->run() == FALSE)
		{
			return $this->load->view('includes/wr/contact_form',NULL,TRUE);
		}
		else
		{
			$this->db->set('name', $this->input->post('name'));
			$this->db->set('email', $this->input->post('email'));
			$this->db->set('message', $this->input->post('message'));
			$this->db->set('ip_address', $this->input->ip_address());
			$this->db->set('current_url', current_url());
			$this->db->set('agent_string', $this->agent->agent_string());
			$this->db->set('agent_referrer', $this->agent->referrer());
			$this->db->set('agent_platform', $this->agent->platform());
			$this->db->insert('ci_wr_contact');
			
			$this->load->model("webresponsemodel", 'webresponse'); // Load the testimonial model
			$data['contact'] = $this->webresponse->contact($this->db->insert_id());
			
			// 10:04:46 PM Mike Alderfer: form should email gwall@aotwp.com and dmattice@aotwp.com
			$this->email->from('noreply@dulworth.com', 'Dulworth Website');
			//$this->email->to('james@netmediapros.com', 'James Clark');
			$this->email->to('info@dulworth.com', 'Mark Dulworth');
			//$this->email->cc('mike@netmediapros.com', 'Mike Alderfer');
			$this->email->subject("Website Response(Contact Us Form)");
			$this->email->message($this->load->view('includes/wr/contact_mailer',$data,TRUE));
			
			if ( ! $this->email->send() )
			{
				echo "Error sending email, please contact website administration.";
			}

			return $this->load->view('includes/wr/contact_thanks',NULL,TRUE);
		}
	}
	
	function _display_gallery($id)
	{
		$this->load->model("gallerymodel", 'galleries');
		
		$data['images'] = $this->galleries->images($id);
		
		if( count($data['images']) > 0 )
		{
			return $this->load->view('includes/gallery',$data,TRUE);
		} else
		{
			return null;
		}
	}
	
	function _format_meta_title($meta_title)
	{
		if( $meta_title == null )
		{
			$site_meta_title = $this->_get_config('meta_title');
			$prefix = $this->_get_config('meta_prefix');
			$suffix = $this->_get_config('meta_suffix');
			
			$meta_title = $prefix . $site_meta_title . $suffix;
		} else
		{
			$prefix = $this->_get_config('meta_prefix');
			$suffix = $this->_get_config('meta_suffix');
			
			$meta_title = $prefix . $meta_title . $suffix;
		}
		
		return $meta_title;
	}
	
	function _format_meta_desc($meta_desc)
	{
		if( $meta_desc == null )
		{
			$meta_desc = $this->_get_config('meta_desc');
		}
		
		return $meta_desc;
	}
	
	function _format_meta_keywords($meta_keywords)
	{
		if( $meta_keywords == null )
		{
			$meta_keywords = $this->_get_config('meta_keywords');
		}
		
		return $meta_keywords;
	}
	
	function _format_meta_footer($meta_footer)
	{
		if( $meta_footer == null )
		{
			$meta_footer = $this->_get_config('meta_footer');
		}
		
		return $meta_footer;
	}
	
	function _format_page_list($exclude=null)
	{
		$pages = $this->pages->parent_pages("0");
		
		if( $exclude )
		{
			$exclude = $this->pages->page($exclude);
		}
		
		if( count($pages) > 0 )
		{
			$menu = '<ul class="navMenu">';
			$menu .= '<li><a title="Dulworth & Company, Inc." href="/" class="Ach">Home</a></li>';
			foreach( $pages as $page )
			{
				$menu .= '<li><a title="' . $page['name'] . '" href="' . $page['url'] . '" class="Ach">' . $page['name'] . '</a>';
				
				/* NO SUBPAGES ON THIS SITE
				if( $this->pages->parent_pages($page['id']) )
				{
					$menu .= '<ul>';
					foreach( $this->pages->parent_pages($page['id']) as $subpage1 )
					{
						$menu .= '<li><a title="' . $page['name'] . ' > ' . $subpage1['name'] . '" href="' . $subpage1['url'] . '">' . $subpage1['name'] . '</a>';
						if( $this->pages->parent_pages($subpage1['id']) )
						{
							foreach( $this->pages->parent_pages($subpage1['id']) as $subpage2 )
							{
								$subpage2['level'] = "10";
								if( $exclude['id'] != $subpage2['id'] )
								{
									$pagelist[] = $subpage2;
								}
							}
						}
						$menu .= '</li>';
					}
					$menu .='</ul>';
				}
				 */
				
				$menu .= '</li>';
			}
			$menu .='</ul>';
			
			return $menu;
		}
		return null;
	}
}

/* End of file main.php */
/* Location: ./system/application/controllers/main.php */