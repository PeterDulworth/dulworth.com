<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-17 11:58:24 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-17 11:58:27 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
