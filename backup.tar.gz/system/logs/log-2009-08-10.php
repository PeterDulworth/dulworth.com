<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-10 12:04:38 --> 404 Page Not Found --> admin/Array
ERROR - 2009-08-10 14:59:05 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-10 14:59:08 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
