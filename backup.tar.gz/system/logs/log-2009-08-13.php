<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-13 10:14:51 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
