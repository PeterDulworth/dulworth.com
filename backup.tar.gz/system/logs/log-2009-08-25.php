<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-25 09:20:35 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-25 09:20:38 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-25 11:06:02 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-25 11:06:05 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
