<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-26 14:25:04 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-26 14:25:07 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-26 15:24:11 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-26 15:24:14 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-26 15:24:16 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-26 15:24:19 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
