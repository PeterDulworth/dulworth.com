<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-09-01 02:48:16 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
