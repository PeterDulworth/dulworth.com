<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-31 09:13:13 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-31 09:13:16 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
