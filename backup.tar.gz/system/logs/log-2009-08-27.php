<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-27 15:45:50 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-27 15:54:17 --> 404 Page Not Found --> http://dev.aotwp.com/lists/link_list.js
ERROR - 2009-08-27 16:01:02 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-27 16:01:03 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-27 22:49:34 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-27 22:49:37 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
