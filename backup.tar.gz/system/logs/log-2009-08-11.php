<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-11 11:13:07 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-11 11:13:10 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-11 11:39:08 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-11 11:39:11 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-11 13:27:13 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-11 13:29:00 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-11 13:29:03 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-11 17:56:42 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-11 17:56:45 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-11 18:36:03 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-11 18:36:06 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-11 18:36:06 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-11 18:43:10 --> 404 Page Not Found --> http://dev.aotwp.com/production/insert-stage
ERROR - 2009-08-11 19:27:25 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-11 19:27:29 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
