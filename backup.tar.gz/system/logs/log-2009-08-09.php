<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-08-09 07:58:44 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2009-08-09 08:44:58 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-09 08:45:01 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
ERROR - 2009-08-09 09:28:56 --> 404 Page Not Found --> http://dev.aotwp.com/favicon.ico
